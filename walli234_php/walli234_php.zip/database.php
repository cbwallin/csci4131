$db_servername = "cse-curly.cse.umn.edu";
$db_username = "C4131S19G117";
$db_password = "13719";
$db_name = "C4131S19G117";
$db_port = 3306;
